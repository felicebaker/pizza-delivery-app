# twilio-python unit tests

## Setup

From the root directory of this repository:

    $ python setup.py develop
    $ pip install -r tests/requirements.txt 

## Running the tests

Again, from the root directory of this repository:

    $ nosetests tests/
