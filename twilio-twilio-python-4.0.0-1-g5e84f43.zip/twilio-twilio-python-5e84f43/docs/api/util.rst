====================
:mod:`twilio.util`
====================

.. automodule:: twilio.util

.. autoclass:: twilio.util.RequestValidator
   :members:

.. autoclass:: twilio.util.TwilioCapability
   :members: allow_client_incoming, allow_client_outgoing, generate


